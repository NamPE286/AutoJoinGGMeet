﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        Click c = new Click();
        private void button1_Click(object sender, EventArgs e)
        {
            check();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        public void func()
        {
            string url = textBox1.Text;
            System.Diagnostics.Process.Start(url);
            Task.Delay(40000).Wait();
            Point p = new Point();
            p.X = 960;
            p.Y = 430;
            c.leftClick(p);
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void MyTimer_Tick(object sender, EventArgs e)
        {
            WakeUpProcess();
        }
        private void WakeUpProcess()
        {
            string h = textBox2.Text;
            string m = textBox3.Text;

            string ctime = h + ":" + m;
            string time = DateTime.Now.ToString("HH:mm");

            if(ctime==time)
            {
                func();
                Application.Exit();
            }
        }
        private void proceed()
        {
            button1.Visible = !button1.Visible;

            this.Text = "Open at " + textBox2.Text + ":" + textBox3.Text;
            label6.Text = "Saved! DO NOT CLOSE THE PROGRAM.";

            Timer MyTimer = new Timer();
            MyTimer.Interval = (1000);
            MyTimer.Tick += new EventHandler(MyTimer_Tick);
            MyTimer.Start();
        }
        private void check()
        {
            if(textBox2.Text.Length == 2 && textBox3.Text.Length == 2)
            {
                proceed();
            }
            else
            {
                label6.Text = "Invalid Input!";
            }
        }
    }
}
